<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kayıtlı Kullanıcılar</title>
</head>
<body>
    <h2>Kayıtlı Kullanıcılar</h2>
    <table border="1">
        <tr>
            <th>İsim</th>
            <th>Soyisim</th>
            <th>E-posta</th>
            <th>Doğum Tarihi</th>
            <th>Cinsiyet</th>
        </tr>
        <?php
        // Veritabanı bağlantısı
        $sunucuAdi = "localhost";
        $kullaniciAdi = "root";
        $veritabaniSifresi = "";
        $veritabaniAdi = "webprogramlama";

        try {
            $conn = new PDO("mysql:host=$sunucuAdi;dbname=$veritabaniAdi", $kullaniciAdi, $veritabaniSifresi);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $conn->prepare("SELECT isim, soyisim, eposta, dogumTarihi, cinsiyet FROM kullanicilar");
            $stmt->execute();

            // Kullanıcıları listele
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['isim']) . "</td>";
                echo "<td>" . htmlspecialchars($row['soyisim']) . "</td>";
                echo "<td>" . htmlspecialchars($row['eposta']) . "</td>";
                echo "<td>" . htmlspecialchars($row['dogumTarihi']) . "</td>";
                echo "<td>" . htmlspecialchars($row['cinsiyet']) . "</td>";
                echo "</tr>";
            }
        } catch(PDOException $e) {
            echo "Bağlantı hatası: " . $e->getMessage();
        }

        $conn = null;
        ?>
    </table>
</body>
</html>

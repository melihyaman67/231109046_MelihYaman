<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $isim = $_POST['isim'];
    $soyisim = $_POST['soyisim'];
    $eposta = $_POST['eposta'];
    $sifre = $_POST['sifre'];
    $dogumTarihi = $_POST['dogumTarihi'];
    $cinsiyet = $_POST['cinsiyet'];

    echo "Form Verileri:<br>";
    echo "İsim: $isim<br>";
    echo "Soyisim: $soyisim<br>";
    echo "E-posta: $eposta<br>";
    echo "Şifre: $sifre<br>";
    echo "Doğum Tarihi: $dogumTarihi<br>";
    echo "Cinsiyet: $cinsiyet<br>";

    // Veritabanı bağlantısı
    $sunucuAdi = "localhost";
    $kullaniciAdi = "root";
    $veritabaniSifresi = "";
    $veritabanAdi = "webprogramlama";

    try {
        $conn = new PDO("mysql:host=$sunucuAdi;dbname=$veritabanAdi", $kullaniciAdi, $veritabaniSifresi);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "Veritabanına başarıyla bağlanıldı.<br>";

        // E-posta benzersiz mi kontrol et
        $stmt = $conn->prepare("SELECT COUNT(*) FROM kullanicilar WHERE email = :eposta");
        $stmt->bindParam(':eposta', $eposta);
        $stmt->execute();
        if ($stmt->fetchColumn() > 0) {
            echo "Bu e-posta adresi zaten kayıtlı.<br>";
            exit();
        }

        // Kullanıcı bilgilerini ekle
        $stmt = $conn->prepare("INSERT INTO kullanicilar (isim, soyisim, email, sifre, dogumTarihi, cinsiyet) VALUES (:isim, :soyisim, :eposta, :sifre, :dogumTarihi, :cinsiyet)");
        $stmt->bindParam(':isim', $isim);
        $stmt->bindParam(':soyisim', $soyisim);
        $stmt->bindParam(':eposta', $eposta);
        $stmt->bindParam(':sifre', password_hash($sifre, PASSWORD_DEFAULT));
        $stmt->bindParam(':dogumTarihi', $dogumTarihi);
        $stmt->bindParam(':cinsiyet', $cinsiyet);

        if ($stmt->execute()) {
            echo "Kayıt başarılı!";
        } else {
            echo "Kayıt eklenirken bir hata oluştu.";
        }
    } catch(PDOException $e) {
        echo "Bağlantı hatası: " . $e->getMessage();
    }

    $conn = null;
}
?>
